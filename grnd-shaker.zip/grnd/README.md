# GRND Shaker

npm install
npm run dev    # http://localhost:3000
npm run build  # Netlify: build `npm run build`, publish `dist/client`
