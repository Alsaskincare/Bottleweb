import { useEffect, useRef } from 'react'
import type * as THREE from 'three'
import flashIcon from 'ionicons/dist/svg/flash.svg?raw'
import bluetoothIcon from 'ionicons/dist/svg/bluetooth.svg?raw'

const FEATURES = [
  {
    icon: flashIcon,
    title: 'Built to last',
    text: 'Designed to match your pace, GRND runs all week on a single charge. No interruptions, no slowing down.',
  },
  {
    icon: bluetoothIcon,
    title: 'Stay synced',
    text: 'With app integration, GRND helps you stay consistent. Monitor intake, set goals, and make every sip count.',
  },
]

export default function GrndSite() {
  const rootRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const root = rootRef.current!
    let disposed = false
    const cleanups: Array<() => void> = []

    ;(async () => {
      const [{ default: gsap }, { ScrollTrigger }, { SplitText }, { default: Lenis }] = await Promise.all([
        import('gsap'),
        import('gsap/ScrollTrigger'),
        import('gsap/SplitText'),
        import('lenis'),
      ])
      if (disposed) return
      gsap.registerPlugin(ScrollTrigger, SplitText)

      const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
      const q = <T extends Element>(s: string) => root.querySelector(s) as T
      const qa = <T extends Element>(s: string) => Array.from(root.querySelectorAll(s)) as T[]

      // Smooth scrolling synced with ScrollTrigger
      let lenis: InstanceType<typeof Lenis> | null = null
      let lenisTick: ((t: number) => void) | null = null
      if (!reduced) {
        lenis = new Lenis({ lerp: 0.1 })
        lenis.on('scroll', ScrollTrigger.update)
        lenisTick = (t: number) => lenis!.raf(t * 1000)
        gsap.ticker.add(lenisTick)
        gsap.ticker.lagSmoothing(0)
      }

      const product = q<HTMLElement>('.product')
      const headline = q<HTMLElement>('.headline')
      const mask = q<HTMLElement>('.mask')
      const sweep = q<HTMLElement>('.sweep')
      const dividers = qa<HTMLElement>('.divider')
      const spin = { r: 0 }
      let dirty = true
      let onSpin: () => void = () => {}

      const ctx = gsap.context(() => {
        // Character reveal as the section approaches
        if (!reduced) {
          const split = SplitText.create(headline, { type: 'chars', mask: 'chars' })
          gsap.from(split.chars, {
            yPercent: 115,
            duration: 0.9,
            ease: 'power3.out',
            stagger: 0.035,
            scrollTrigger: { trigger: product, start: 'top 85%', toggleActions: 'play none none reverse' },
          })
        }

        const tl = gsap.timeline({
          defaults: { ease: 'none' },
          scrollTrigger: {
            trigger: product,
            start: 'top top',
            end: '+=1000%',
            pin: true,
            scrub: reduced ? true : 1,
            invalidateOnRefresh: true,
          },
        })

        tl.fromTo(headline, { x: 0 }, { x: () => -(headline.scrollWidth - window.innerWidth * 0.5), duration: 0.3 }, 0.05)
          .fromTo(mask, { clipPath: 'circle(0% at 50% 50%)' }, { clipPath: 'circle(100% at 50% 50%)', duration: 0.1 }, 0.2)
          .fromTo(sweep, { x: () => window.innerWidth }, { x: () => -sweep.offsetWidth, duration: 0.35 }, 0.15)
          .fromTo(dividers, { scaleX: 0 }, { scaleX: 1, duration: 0.2 }, 0.45)

        ;[0.65, 0.85].forEach((at, i) => {
          const f = qa<HTMLElement>('.feature')[i]
          tl.fromTo(
            f.querySelectorAll('.rv'),
            { yPercent: 115 },
            { yPercent: 0, duration: 0.1, stagger: 0.02, ease: 'power2.out' },
            at,
          )
        })

        tl.fromTo(
          spin,
          { r: 0 },
          { r: 12 * Math.PI, duration: 0.95, onUpdate: () => onSpin() },
          0.05,
        )
      }, root)

      // ---------- Three.js ----------
      const THREE = await import('three')
      const { GLTFLoader } = await import('three/examples/jsm/loaders/GLTFLoader.js')
      const { DRACOLoader } = await import('three/examples/jsm/loaders/DRACOLoader.js')
      const { RoomEnvironment } = await import('three/examples/jsm/environments/RoomEnvironment.js')
      if (disposed) {
        ctx.revert()
        return
      }

      const canvas = q<HTMLCanvasElement>('canvas')
      const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true })
      renderer.setClearColor(0x000000, 0)
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

      const scene = new THREE.Scene()
      const pmrem = new THREE.PMREMGenerator(renderer)
      const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture
      scene.environment = envTex
      scene.environmentIntensity = 0.15
      scene.add(new THREE.AmbientLight(0xffffff, 0.55))
      const key = new THREE.DirectionalLight(0xffffff, 1.1)
      key.position.set(3, 4, 5)
      const rim = new THREE.DirectionalLight(0xffffff, 0.35)
      rim.position.set(-4, 2, -3)
      scene.add(key, rim)

      const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 100)
      const tilt = new THREE.Group()
      tilt.rotation.z = THREE.MathUtils.degToRad(-25)
      const spinGroup = new THREE.Group()
      tilt.add(spinGroup)
      scene.add(tilt)

      const size = new THREE.Vector3(1, 1, 1)
      const fit = () => {
        const w = canvas.clientWidth || window.innerWidth
        const h = canvas.clientHeight || window.innerHeight
        renderer.setSize(w, h, false)
        camera.aspect = w / h
        const mobile = w < 1000
        const a = THREE.MathUtils.degToRad(25)
        const horiz = Math.max(size.x, size.z)
        const tiltedH = size.y * Math.cos(a) + horiz * Math.sin(a)
        const frac = mobile ? 0.4 : 0.74
        const visH = tiltedH / frac
        const dist = visH / 2 / Math.tan(THREE.MathUtils.degToRad(camera.fov / 2))
        camera.position.set(0, 0, dist)
        camera.updateProjectionMatrix()
        tilt.position.set(mobile ? 0 : 0.082 * visH * camera.aspect, mobile ? (0.5 - 0.34) * visH : -0.0508 * visH, 0)
        dirty = true
      }
      onSpin = () => {
        spinGroup.rotation.y = spin.r
        dirty = true
      }

      const draco = new DRACOLoader()
      draco.setDecoderPath('/draco/')
      const loader = new GLTFLoader()
      loader.setDRACOLoader(draco)
      loader.load(
        '/models/grnd-shaker.glb',
        (gltf) => {
          if (disposed) return
          const model = gltf.scene
          const box = new THREE.Box3().setFromObject(model)
          box.getSize(size)
          model.position.sub(box.getCenter(new THREE.Vector3()))
          spinGroup.add(model)
          onSpin()
          fit()
        },
        undefined,
        (e) => console.error('GLB failed to load', e),
      )

      fit()
      window.addEventListener('resize', fit)
      const renderTick = () => {
        if (!dirty) return
        dirty = false
        renderer.render(scene, camera)
      }
      gsap.ticker.add(renderTick)

      cleanups.push(() => {
        window.removeEventListener('resize', fit)
        gsap.ticker.remove(renderTick)
        if (lenisTick) gsap.ticker.remove(lenisTick)
        lenis?.destroy()
        ctx.revert()
        ScrollTrigger.getAll().forEach((s) => s.kill())
        scene.traverse((o) => {
          const m = o as THREE.Mesh
          if (!m.isMesh) return
          m.geometry.dispose()
          const mats = Array.isArray(m.material) ? m.material : [m.material]
          mats.forEach((mat) => {
            Object.values(mat).forEach((v) => {
              if (v && (v as THREE.Texture).isTexture) (v as THREE.Texture).dispose()
            })
            mat.dispose()
          })
        })
        draco.dispose()
        envTex.dispose()
        pmrem.dispose()
        renderer.dispose()
        renderer.forceContextLoss()
      })
    })()

    return () => {
      disposed = true
      cleanups.forEach((fn) => fn())
    }
  }, [])

  return (
    <div ref={rootRef}>
      <section className="screen centered">
        <h1>
          GRND doesn't shake.
          <br />
          It performs.
        </h1>
      </section>

      <section className="screen product">
        <div className="headline-wrap">
          <h2 className="big headline">Every Rep Starts With</h2>
        </div>
        <div className="mask" aria-hidden="true">
          <p className="big sweep">GRND Shaker</p>
        </div>
        <div className="features">
          {FEATURES.map((f) => (
            <div className="feature" key={f.title}>
              <div className="divider" />
              <div className="clip icon" aria-hidden="true">
                <span className="rv" style={{ height: '100%' }} dangerouslySetInnerHTML={{ __html: f.icon }} />
              </div>
              <h3 className="clip">
                <span className="rv">{f.title}</span>
              </h3>
              <p className="clip">
                <span className="rv">{f.text}</span>
              </p>
            </div>
          ))}
        </div>
        <canvas className="canvas" aria-hidden="true" />
      </section>

      <section className="screen centered">
        <h1>Don't Just Train — GRND</h1>
      </section>
    </div>
  )
}
