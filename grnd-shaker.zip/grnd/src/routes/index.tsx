import { createFileRoute } from '@tanstack/react-router'
import GrndSite from '../components/GrndSite'

export const Route = createFileRoute('/')({ component: GrndSite })
